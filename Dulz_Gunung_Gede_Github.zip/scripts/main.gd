extends Node3D

var player: CharacterBody3D
var camera: Camera3D
var interact_label: Label
var info_label: Label
var shop_panel: Panel
var coin := 1000
var diamond := 0
var inventory := {"Air Mineral": 0, "Makanan": 0, "Snack": 0, "Senter": 0, "Baterai": 0, "Tenda": 0, "Jaket": 0}

func _ready():
    _build_world()
    _build_player()
    _build_ui()
    _update_info()

func mat(color: Color, roughness := 0.8) -> StandardMaterial3D:
    var m = StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = roughness
    return m

func box(size: Vector3, position: Vector3, color: Color, parent: Node3D = self):
    var body = StaticBody3D.new()
    body.position = position
    parent.add_child(body)
    var mesh = MeshInstance3D.new()
    var b = BoxMesh.new()
    b.size = size
    mesh.mesh = b
    mesh.material_override = mat(color)
    body.add_child(mesh)
    var col = CollisionShape3D.new()
    var shape = BoxShape3D.new()
    shape.size = size
    col.shape = shape
    body.add_child(col)
    return body

func cylinder(radius: float, height: float, position: Vector3, color: Color, parent: Node3D = self):
    var body = StaticBody3D.new()
    body.position = position
    parent.add_child(body)
    var mesh = MeshInstance3D.new()
    var c = CylinderMesh.new()
    c.top_radius = radius
    c.bottom_radius = radius
    c.height = height
    mesh.mesh = c
    mesh.material_override = mat(color)
    body.add_child(mesh)
    var col = CollisionShape3D.new()
    var shape = CylinderShape3D.new()
    shape.radius = radius
    shape.height = height
    col.shape = shape
    body.add_child(col)
    return body

func label3d(text: String, position: Vector3, size := 28):
    var l = Label3D.new()
    l.text = text
    l.position = position
    l.font_size = size
    l.outline_size = 8
    l.modulate = Color(1, 1, 1)
    add_child(l)
    return l

func _build_world():
    # Ground and trail
    box(Vector3(80, 1, 80), Vector3(0, -0.5, 0), Color(0.10, 0.16, 0.08))
    box(Vector3(9, 0.25, 65), Vector3(0, 0.15, -4), Color(0.24, 0.16, 0.10))

    # Gate: stone + wood landmark
    box(Vector3(2.5, 7, 2.5), Vector3(-6, 3.5, -25), Color(0.27, 0.27, 0.25))
    box(Vector3(2.5, 7, 2.5), Vector3(6, 3.5, -25), Color(0.27, 0.27, 0.25))
    box(Vector3(15, 2, 2.5), Vector3(0, 7, -25), Color(0.22, 0.12, 0.06))
    box(Vector3(11, 1.2, 1.0), Vector3(0, 5.9, -25), Color(0.36, 0.20, 0.08))
    label3d("DULZ GUNUNG GEDE", Vector3(0, 6.4, -23.7), 42)
    label3d("GAPURA UTAMA • MULAI PENDAKIAN", Vector3(0, 4.8, -23.7), 18)

    # Two houses at the gate
    _make_house(Vector3(-14, 0, -19), "RUMAH PERALATAN", Color(0.22, 0.10, 0.05))
    _make_house(Vector3(14, 0, -19), "TOKO LOGISTIK", Color(0.10, 0.16, 0.20))

    # Shop signs
    label3d("AIR • MAKANAN • TENDA • JAKET", Vector3(-14, 4.3, -17.8), 15)
    label3d("SNACK • SENTER • BATERAI", Vector3(14, 4.3, -17.8), 15)

    # POS 1
    _make_house(Vector3(-11, 0, 8), "POS 1", Color(0.18, 0.11, 0.06))
    label3d("POS 1 • CHECKPOINT", Vector3(-11, 4.0, 9.3), 22)

    # Camping area
    _make_tent(Vector3(13, 0.2, 12))
    _make_tent(Vector3(18, 0.2, 15))
    label3d("CAMPING AREA", Vector3(15, 3.5, 13), 24)

    # Trees
    for z in range(-20, 31, 7):
        _tree(Vector3(-22 + sin(z) * 3.0, 0, z))
        _tree(Vector3(22 + cos(z) * 3.0, 0, z))

    # Simple roots / rocks for less-flat trail
    for i in range(12):
        var x = -3.5 + fmod(float(i) * 1.73, 7.0)
        var z = -10 + i * 3.2
        box(Vector3(5.5, 0.35, 0.5), Vector3(x, 0.35 + (i%2)*0.15, z), Color(0.18,0.11,0.07))

    # Checkpoint markers
    label3d("▼ START", Vector3(0, 1.5, -29), 22)
    label3d("● CHECKPOINT POS 1", Vector3(0, 1.5, 12), 18)

    # Lighting / fog
    var sun = DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -25, 0)
    sun.light_energy = 1.2
    add_child(sun)
    var world = WorldEnvironment.new()
    var env = Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color(0.28, 0.40, 0.48)
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.55,0.62,0.66)
    env.ambient_light_energy = 0.7
    env.fog_enabled = true
    env.fog_light_color = Color(0.55,0.62,0.65)
    env.fog_density = 0.008
    world.environment = env
    add_child(world)

func _make_house(pos: Vector3, title: String, roof_color: Color):
    box(Vector3(10, 4, 7), pos + Vector3(0,2,0), Color(0.34,0.25,0.18))
    box(Vector3(11, 0.8, 8), pos + Vector3(0,4.4,0), roof_color)
    box(Vector3(2, 2.5, 0.25), pos + Vector3(0,1.3,-3.55), Color(0.08,0.05,0.03))
    label3d(title, pos + Vector3(0,5.8,0), 24)

func _make_tent(pos: Vector3):
    var body = MeshInstance3D.new()
    var prism = PrismMesh.new()
    prism.size = Vector3(4, 2.7, 4)
    body.mesh = prism
    body.position = pos + Vector3(0,1.35,0)
    body.material_override = mat(Color(0.55,0.18,0.05))
    add_child(body)

func _tree(pos: Vector3):
    cylinder(0.45, 5, pos + Vector3(0,2.5,0), Color(0.22,0.12,0.06))
    var crown = MeshInstance3D.new()
    var sphere = SphereMesh.new()
    sphere.radius = 2.5
    sphere.height = 5.5
    crown.mesh = sphere
    crown.position = pos + Vector3(0,6,0)
    crown.material_override = mat(Color(0.07,0.22,0.10))
    add_child(crown)

func _build_player():
    player = CharacterBody3D.new()
    player.position = Vector3(0, 1.2, -31)
    add_child(player)
    var capsule = MeshInstance3D.new()
    var mesh = CapsuleMesh.new()
    mesh.height = 1.8
    mesh.radius = 0.42
    capsule.mesh = mesh
    capsule.material_override = mat(Color(0.05,0.20,0.45))
    player.add_child(capsule)
    var col = CollisionShape3D.new()
    var shape = CapsuleShape3D.new()
    shape.height = 1.8
    shape.radius = 0.42
    col.shape = shape
    player.add_child(col)

    camera = Camera3D.new()
    camera.position = Vector3(0, 3.2, 6.5)
    camera.look_at_from_position(camera.global_position, player.global_position + Vector3(0,1,0))
    player.add_child(camera)
    camera.current = true

func _build_ui():
    var layer = CanvasLayer.new()
    add_child(layer)

    info_label = Label.new()
    info_label.position = Vector2(24, 20)
    info_label.add_theme_font_size_override("font_size", 22)
    layer.add_child(info_label)

    interact_label = Label.new()
    interact_label.position = Vector2(24, 110)
    interact_label.add_theme_font_size_override("font_size", 20)
    layer.add_child(interact_label)

    var title = Label.new()
    title.text = "DULZ GUNUNG GEDE  •  PROTOTYPE"
    title.position = Vector2(24, 650)
    title.add_theme_font_size_override("font_size", 20)
    layer.add_child(title)

    var hint = Label.new()
    hint.text = "WASD = jalan   |   E = interaksi   |   Dekati rumah/toko"
    hint.position = Vector2(24, 680)
    hint.add_theme_font_size_override("font_size", 17)
    layer.add_child(hint)

func _update_info():
    info_label.text = "Dulz\nID: DZG-48291\n🪙 %d   💎 %d\nCheckpoint: GAPURA" % [coin, diamond]

func _physics_process(delta):
    if not player:
        return
    var input_vec = Input.get_vector("move_left", "move_right", "move_forward", "move_back")
    var dir = Vector3(input_vec.x, 0, input_vec.y)
    player.velocity.x = dir.x * 5.0
    player.velocity.z = dir.z * 5.0
    if not player.is_on_floor():
        player.velocity.y -= 18.0 * delta
    else:
        player.velocity.y = 0
    player.move_and_slide()
    camera.look_at(player.global_position + Vector3(0,1,0))
    _interaction_check()

func _interaction_check():
    var d = player.global_position
    if d.distance_to(Vector3(-14,0,-19)) < 10:
        interact_label.text = "🏠 RUMAH PERALATAN\nDekati dan tekan E untuk membuka toko."
    elif d.distance_to(Vector3(14,0,-19)) < 10:
        interact_label.text = "🛒 TOKO LOGISTIK\nDekati dan tekan E untuk membeli kebutuhan."
    elif d.distance_to(Vector3(0,0,-29)) < 7:
        interact_label.text = "🚪 GAPURA DULZ GUNUNG GEDE\nCheckpoint awal pendakian."
    else:
        interact_label.text = ""

    if Input.is_action_just_pressed("interact"):
        if d.distance_to(Vector3(-14,0,-19)) < 10:
            _buy("Air Mineral", 20)
        elif d.distance_to(Vector3(14,0,-19)) < 10:
            _buy("Snack", 25)

func _buy(item: String, price: int):
    if coin >= price:
        coin -= price
        inventory[item] += 1
        interact_label.text = "Berhasil membeli %s (-%d Coin)." % [item, price]
        _update_info()
    else:
        interact_label.text = "Coin tidak cukup."

func _unhandled_input(event):
    if event is InputEventScreenTouch and event.pressed:
        # Prototype touch: tap left/right side to strafe, top/bottom to move.
        var size = get_viewport().get_visible_rect().size
        var p = event.position
        if p.y < size.y * 0.45:
            player.velocity.z = -4.0
        elif p.y > size.y * 0.7:
            player.velocity.z = 4.0
        elif p.x < size.x * 0.5:
            player.velocity.x = -4.0
        else:
            player.velocity.x = 4.0
