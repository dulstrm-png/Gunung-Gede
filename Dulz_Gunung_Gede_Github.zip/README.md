# DULZ GUNUNG GEDE

Prototype game 3D online-multiplayer bertema simulasi pendakian.

## Isi prototype
- Gapura utama "DULZ GUNUNG GEDE"
- Rumah peralatan di area gapura
- Toko logistik lain di area gapura
- Pos 1 / checkpoint
- Camping area dan tenda
- Jalur tanah, akar, batu, pohon, kabut dan lighting dasar
- Player 3D + kamera third-person sederhana
- Coin + Diamond
- ID pemain contoh `DZG-48291`
- Interaksi toko dasar
- Siap dikembangkan menjadi sistem akun, friends, room, multiplayer, inventory, survival, top-up resmi dan save server.

## Jalankan di Godot
Buka folder ini di Godot 4.x lalu Run Project.

## Build Android melalui GitHub Actions
Workflow berada di:
`.github/workflows/build-apk.yml`

Push repository ke GitHub, buka tab **Actions**, jalankan workflow **Build Android APK**.

> APK prototype ini tidak dibuat-buat menjadi 1 GB. Ukuran akhir mengikuti asset dan dependency nyata. Target 1 GB harus dicapai dengan konten game asli (terrain, texture, audio, animasi, model, dll.), bukan file dummy karena itu akan memperberat GitHub dan memperlambat build.

## Catatan multiplayer
Prototype ini belum mengaktifkan server multiplayer produksi. Struktur gameplay sudah disiapkan agar sistem online dapat ditambahkan tanpa mengubah konsep dunia awal.
