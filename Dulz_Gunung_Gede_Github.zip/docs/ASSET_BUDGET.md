# TARGET UKURAN GAME ±1 GB

Target ukuran game sekitar 1 GB harus berasal dari asset nyata, bukan padding/dummy.

Contoh pembagian budget:
- Environment 3D: 350 MB
- Character + animation: 180 MB
- Terrain/rocks/vegetation: 180 MB
- Audio/music/SFX: 120 MB
- UI/VFX: 70 MB
- Additional maps/LOD: 70 MB
- Localization/config/other: 30 MB

Untuk Android produksi, pertimbangkan AAB + Play Asset Delivery/asset packs agar APK dasar tidak dipaksa memuat seluruh 1 GB.
